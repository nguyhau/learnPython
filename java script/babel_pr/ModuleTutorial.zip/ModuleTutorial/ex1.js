var myModule = require("my-module")

myModule()
