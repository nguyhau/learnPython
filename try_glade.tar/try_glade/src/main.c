#include <gtk/gtk.h>
static void
activate (GtkApplication *app,
          gpointer        user_data)
{
    GtkBuilder      *builder; 
    GtkWidget       *window;
    // add css
    GtkCssProvider *provider;
    GdkDisplay *display;
    GdkScreen *screen;
 
//    gtk_init(&argc, &argv);
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "glade/window_main.glade", NULL);
 
    window = GTK_WIDGET(gtk_builder_get_object(builder, "window_main"));// get object from builder by ID name
    gtk_builder_connect_signals(builder, NULL);
 
    gtk_application_add_window (app, GTK_WINDOW (window));// GTK_WINDOW will check if pointer is an instance of GtkWindow class before casting. 
    g_object_unref(builder);
//  create css provider
    provider = gtk_css_provider_new ();
//  get screen for apply css
    display = gdk_display_get_default ();
    screen = gdk_display_get_default_screen (display);
    GError *error = 0;
    gboolean bcheck = FALSE;
    bcheck=gtk_css_provider_load_from_file(GTK_CSS_PROVIDER (provider), g_file_new_for_path("css/stype.css"), &error);
    if (bcheck == FALSE ){
          g_critical("Read css file faild\n");
          g_print("Hello world\n");
          g_critical(error->message);
    }
    else{
          g_critical("Read css file success\n");
          g_print("Hello world\n");
    	  gtk_style_context_add_provider_for_screen (screen, GTK_STYLE_PROVIDER (provider),    GTK_STYLE_PROVIDER_PRIORITY_USER);
//	  gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(provider), GTK_STYLE_PROVIDER_PRIORITY_USER);
         }
    g_object_unref (provider);
    gtk_widget_show_all(window);                
  //  gtk_main();
 
   // return 0;
}
 
int
main (int    argc,
      char **argv)
{
  GtkApplication *app;
  int status;

  app = gtk_application_new ("org.gtk.example", G_APPLICATION_FLAGS_NONE);
  g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);// gtk_init() and gtk_main() provide by g_application_run().
  status = g_application_run (G_APPLICATION (app), argc, argv);
  g_object_unref (app);

  return status;
}
// called when window is closed
void on_window_main_destroy()
{
    gtk_main_quit();
}
