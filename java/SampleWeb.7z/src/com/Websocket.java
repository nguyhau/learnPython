package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Enumeration;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/endpoint")
public class Websocket {
	// Web socket core properties
	private Session mSession = null;
	private byte[] mData = new byte[4096];
	public static int num_pkg = 0;
	
	// RTP socket properties
	RTPHandle rtp = null;
	MulticastSocket socket = null;
	DatagramPacket rcvdp = null;
	public static String gr_address = "224.4.0.1";
	public static int port = 50420;
	public static int NIC_numb = 50420;
	
	// RTP states
	private int rtp_state = 0;
	final static int INIT = 0;
	final static int READY = 1;
	final static int PLAYING = 2;
	
	// request types
	final static int CONFIG = 1;
	final static int PLAY = 2;
	final static int PAUSE = 3;
	final static int STOP = 4;	

	static int state; //RTP Socket state == INIT or READY or PLAY
	
	// For testing
	private static int index = 0;
	
	public void initRtpSocket(int port, String grAddr, int ifNumb) throws IOException {
		System.out.println("Connect to multicast");

		// Create a new Multicast socket
		socket = new MulticastSocket(port);		

		// Get network ip
		String ip = InetAddress.getLocalHost().getHostAddress();
		System.out.println(" IP init is " + ip);
		try {
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			int index = 0;
			boolean stop = false;
			while (interfaces.hasMoreElements() && (!stop)) {
				NetworkInterface iface = interfaces.nextElement();
				// filters out 127.0.0.1 and inactive interfaces
				if (iface.isLoopback() || !iface.isUp())
					continue;

				Enumeration<InetAddress> addresses = iface.getInetAddresses();
				while (addresses.hasMoreElements()) {
					InetAddress addr = addresses.nextElement();					
					if ((addr instanceof Inet4Address) && (index == ifNumb)) {
						ip = addr.getHostAddress();						
						stop = true;
					}
					index++;
				}
			}			
		} catch (SocketException e) {
			throw new RuntimeException(e);
		}
		// Set network interface
		//System.out.println("IP final is " + ip);
		System.out.println("===== RTP socket is ready .");
		//System.out.println("For run with Colasoft from other computer: set Interface is important!");		
		//socket.setInterface(InetAddress.getByName(ip));		

		// Joint the Multicast group		
		InetAddress address = InetAddress.getByName(grAddr);
		socket.joinGroup(address);
		rtp_state = READY;
	}

	public void sendData(byte[] bytes, int count) throws IOException, InterruptedException {
		num_pkg++;
		ByteBuffer buf = ByteBuffer.wrap(bytes, 0, count);
		mSession.getBasicRemote().sendBinary(buf);
		buf.clear();
		System.out.println("Sended " + num_pkg + " package to Browser");
	}

	@OnOpen
	public void onOpen(Session session) throws SocketException, Exception {

		//System.out.println("onOpen::" + session.getId());		
		mSession = session;
		//session.getBasicRemote().sendText("Hello Client " + session.getId() + "!");		
		System.out.println("===== Websocket connected.");
	}

	@OnClose
	public void onClose(Session session) {
		//System.out.println("onClose::" + session.getId());
	}

	// For testing websocket
	public void sendh264() {
		try {			
			String FileName = "E:\\Bunny\\chunk_dash";
			if (index == 0) {
				FileName = FileName + "init.mp4";
			} else {
				FileName = FileName + index + ".m4s";
			}
			if (index < 31) {
				File file = new File(FileName);
				// Get the size of the file
				//long length = file.length();
				byte[] bytes = new byte[1024];
				InputStream in = new FileInputStream(file);
				System.out.println("Send file" + FileName);
				int count;
				while ((count = in.read(bytes)) > 0) {
					num_pkg++;
					ByteBuffer buf = ByteBuffer.wrap(bytes, 0, count);
					mSession.getBasicRemote().sendBinary(buf);
				}
				in.close();
				mSession.getBasicRemote().sendText("Hello Client " + mSession.getId() + "!");
			}
			index++;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	//------------------------------------
	//Parse Webapp Request
	//------------------------------------
	private int parseRequest(String request) {
		int request_type = -1;
		try {
			//convert to request_type structure:
			if ((new String(request)).toLowerCase().contains("config"))
				request_type = CONFIG;
			else if ((new String(request)).toLowerCase().contains("start"))
				request_type = PLAY;
			else if ((new String(request)).toLowerCase().contains("pause"))
				request_type = PAUSE;
			else if ((new String(request)).toLowerCase().contains("stop"))
				request_type = STOP;            

			if (request_type == CONFIG) {
				//extract VideoFileName from RequestLine
				String[] element_arr = request.split(";");
				for (int i = 0; i < element_arr.length; i++)
				{
					String[] part_arr = element_arr[i].split(":");
					switch (i) {
					// IP
					case 0:
						gr_address = part_arr[1];
						break;
						// Port
					case 1:
						port = Integer.parseInt(part_arr[1]);
						break;
						// NIC number
					case 2:
						NIC_numb = Integer.parseInt(part_arr[1]);
						break;					 
					default:
						System.out.println("Somethings wrong");
					}
				}
				System.out.println("Config parameter of RTP: IP" + gr_address + " port " + port + " NIC nubmer "+ NIC_numb);
			}


		} catch(Exception ex) {
			System.out.println("Exception caught: "+ex);
			System.exit(0);
		}

		return(request_type);
	}


	@OnMessage
	public void onMessage(String message, Session session) {
		//System.out.println("onMessage::From=" + session.getId() + " Message=" +	message);
		gr_address ="224.4.0.1";
		port = 50420;
		NIC_numb = 0;
		int request_type = parseRequest(message);
		try {
			switch (request_type) {
			 // IP
			case CONFIG:
				 System.out.println("Receive CONFIG request from Browser");
				 initRtpSocket(port, gr_address, NIC_numb);
				 rtp = new RTPHandle(socket, mData, this);
			     break;
			 // Port
			 case PLAY:
				 System.out.println("Receive PLAY request from Browser");
				 if (rtp_state == READY) {
						rtp.start();
						System.out.println("Running");
				 } else if (rtp_state == STOP) {
					 rtp.setStatus(false);
				 }
		         //rtp.start();
		         // Sample for MSE
		 		 //sendh264();
			     break;
			 // NIC number
			 case PAUSE:			 
			     break;					 
			 case STOP:
				 rtp.setStatus(true);
				 rtp_state = STOP;
			     break;					 
			 default:
			     System.out.println("Somethings wrong");
			 }
		}
		catch (Exception e) {
			// TODO: handle exception
		}			

	}

	@OnError
	public void onError(Throwable t) {
		System.out.println("onError::" + t.getMessage());
	}
}
