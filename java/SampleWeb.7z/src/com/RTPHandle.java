package com;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.MulticastSocket;
import java.util.Arrays;

public class RTPHandle extends Thread{

	public static long num_pkg = 0;
	// TS package constant
	public static int INDEX_SIZE = 4;
	public static int PES_SIZE = 188;
	// Private properties
	Websocket web_socket = null;
	MulticastSocket RTPsocket;
	byte[] buffer;
	private boolean stop = false;
	// For singleton pattern
	private static RTPHandle instance;

	public RTPHandle(MulticastSocket socket, byte[] buff, Websocket wbsoc) {
		this.RTPsocket = socket;
		this.buffer = buff;
		this.web_socket = wbsoc;
	}

	// For singleton pattern
	public static RTPHandle getInstance(MulticastSocket socket, byte[] buff, Websocket wbsoc) {
		if(instance == null) {
			synchronized(RTPHandle.class) {
				if(null == instance) {
					instance  = new RTPHandle(socket, buff, wbsoc);
				}
			}
		}
		instance.RTPsocket = socket;
		instance.buffer = buff;
		instance.web_socket = wbsoc;
		return instance;
	}
	public void setStatus(boolean stt) {
		this.stop = stt;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		long counter = 0;
		byte [] payload = null;
		DatagramPacket rcvdp = null;
		try {
			while (true) {

				// Receive the information and print it.
				System.out.println("Waiting data from RTP socket");
				rcvdp = new DatagramPacket(buffer, buffer.length);
				RTPsocket.receive(rcvdp);
				//System.out.println("Receive data 3 length" + rcvdp.getLength());
				counter++;
				String msg = "Received " + counter + " package from RTP socket";
				System.out.println(msg );
				// Create an RTPpacket object from the DP
				RTPpacket rtp_packet = new RTPpacket(rcvdp.getData(), rcvdp.getLength());
				// Get the payload bitstream from the RTPpacket object
				int payload_length = rtp_packet.getpayload_length();
				payload = new byte[payload_length];
				rtp_packet.getpayload(payload);
				int numbPESpkg;
				numbPESpkg = payload_length/(INDEX_SIZE + PES_SIZE);
				byte [] h264raw = new byte[numbPESpkg*PES_SIZE];
				int pes_index, pay_index;
				pes_index = 0;
				pay_index = INDEX_SIZE;
				for (int i= 0; i < numbPESpkg; i++)
				{
					for (int j = 0; j < PES_SIZE; j++)
					{
						h264raw[pes_index + j] = payload[pay_index+j];
					}
					pes_index = pes_index + PES_SIZE;
					pay_index = pes_index + INDEX_SIZE;
				}
				// write buffer to file 
				//FileOutputStream saltOutFile = new FileOutputStream("E:\\payload.enc", true);
				//saltOutFile.write(h264raw);
				//saltOutFile.write(rcvdp.getData());
				//saltOutFile.close();
				if (stop) continue;
				if (payload_length != 0) {
					//web_socket.sendData(h264raw, pes_index);
					web_socket.sendData(rcvdp.getData(), rcvdp.getLength());
					//web_socket.sendData(payload, payload_length);
				}
				Arrays.fill(buffer, (byte)0);
				payload_length = 0;
				//Thread.sleep(500);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


